#include<iostream>
#include<list>
using namespace std;

void display(list<int> lsst){
    list<int> :: iterator it;
    for(it= lsst.begin();it!=lsst.end();it++){
        cout<<*it<< " ";
    }
    cout<<endl;
}

int main(){
    list<int> list1;
    list1.push_back(90);
    list1.push_back(910);
    list1.push_back(92);
    list1.push_back(93);
    list1.push_back(94);
    list1.push_back(95);
    list1.push_back(96);
    list1.push_back(97);
    list1.pop_front();
    list1.remove(95);
    list<int> :: iterator iter;

    iter = list1.begin();
    // list1.assign(iter, 9000);
    list<int> :: iterator iter1;
    // iter1= list1.end();
    list1.sort();
    display(list1);
    cout<<"hi";
    return 0;
}


/*

list<int> list;
list.push_back();
list.pop_back();
list.pop_front();
list.remove();
list.sort();
list<int> list1;
list.merge(list1);
list.reverse();


*/

