#include<string>
#include<iostream>

using namespace std;

int main(){
    string fname, lname,fullName;
    cout<<"Enter first name : ";
    cin>>fname;
    cout<<"Enter last name : ";
    cin>>lname;
    fname = fname.append(" ");
    fullName= fname.append(lname);

    cout<<"Full name is "<<fullName<< " and name length is "<< fullName.length()<< " name's first letter is "<<fullName[0]<< " whose ASCII valule is "<<int(fullName[0])<<" And alphabetical position is "<< int(fullName[0])-64<<endl;
}