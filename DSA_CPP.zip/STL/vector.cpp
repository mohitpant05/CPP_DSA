#include<iostream>
#include<vector>

using namespace std;
template <class T>
void display(T &v){
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}

int main(){
    vector<char> v1;
    int size;
    char element;
    cout<<"Enter the number of elements you want to enter : ";
    cin>>size;
    for(int i=0;i<size;i++){
        cout<<"Enter your value : ";
        cin>>element;
        v1.push_back(element);
    }
    display(v1);
    cout<<v1.empty()<<endl;
    vector<char> b(90);
    vector<char> :: iterator iter;
    iter = b.end();

    b.insert(iter-1,'d');

    display(b);
    return 0;
}