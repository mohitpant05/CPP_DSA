// working fine on online compiler
#include <iostream>
// #include <iomanip>
using namespace std;

typedef struct node{
    int data;
    struct node *right;
    struct node *left;
    
}tr;


void preorder(tr * temp){
    if(temp!=NULL){
        

       
        cout<<temp->data<<"    ";
        
        preorder(temp->left);
        preorder(temp->right);
    }
}

void postorder(tr * temp){
    if(temp!=NULL){
        
        postorder(temp->left);
        postorder(temp->right);
        cout<<temp->data<<"    ";
    }
}

void inorder(tr * temp){
    if(temp!=NULL){
        
        inorder(temp->left);
        

       
        cout<<temp->data<<"    ";
        inorder(temp->right);
        
    }
}

int main()
{
    tr * rt = new tr;
    tr * p1= new tr;
    tr * p2 = new tr;
    tr * c1=new tr;
    tr * c2=new tr;
    tr* c3 = new tr;
    
    rt->data=1;
    rt->left=p1;
    rt->right=p2;
    
    p1->data=2;
    p1->left=c1;
    p1->right=c2;
    
    c1->data=4;
    c2->data=5;
    
    p2->data=3;
    p2->left=c3;
    // p2->right=c2;
    
    c3->data=6;
    cout<<"Preorder Traversal :  ";
    
    preorder(rt);

    cout<<endl;
      cout<<"Postorder Traversal : ";
    
    postorder(rt);
    cout<<endl;
      cout<<"Inorder Traversal :   ";
    
    inorder(rt);
    return 0;
}