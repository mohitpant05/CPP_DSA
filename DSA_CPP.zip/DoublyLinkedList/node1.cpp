#include <iostream>

using namespace std;

typedef struct Dnode{
    int data;
    struct Dnode * next;
    struct Dnode * prev;
}dnd;

dnd * head = NULL;

    void insert(dnd* temp, int data){

        if(head==NULL){
            temp->next=NULL;
            temp->prev=NULL;
            temp->data=data;
            head=temp;

            cout<<"Node inserted sucesfuly"<<endl;
            return;
        }
        while(temp->next!=NULL){
            temp=temp->next;
        }
        dnd * ptr=new dnd;
        ptr->data=data;

        ptr->next=NULL;
        ptr->prev=temp;
        temp->next=ptr;
        cout<<"Node inserted sucesfuly"<<endl;
        return;
        
    }

    void display(dnd * temp){
        while(temp!=NULL){
            cout<<temp->data<<endl;
            temp=temp->next;
        }

    }

    void doublyLinkedList(){

        dnd * ptr = new dnd;
        insert(ptr, 45);
        display(ptr);

        return;


    }



int main(){

    doublyLinkedList();

    return 9;
}