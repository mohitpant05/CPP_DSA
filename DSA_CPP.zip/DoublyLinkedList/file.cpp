#include<iostream>
#include<fstream>
using namespace std;

int main(){
    
    string strf = "hellow world \n hi \n I am here";
    string str;

    ofstream out;
    out.open("2.txt");
    out<<strf;


    ifstream in("2.txt");
   
   while(in.eof()!=0){
    getline(in,str);
    cout<<str;
   }

    return 0;
}