#include<iostream>

using namespace std;;

typedef struct node {
    int data;
    struct node * next;
}nd;

nd * head = NULL;


void append(nd ** head_ref,int value){

    nd * instPtr = new nd;
    instPtr->data= value;
    nd * ptr = *head_ref;
    instPtr->next= NULL;

    if((*head_ref) == NULL){
        (*head_ref)=instPtr;
        cout<<"Node inserted Successfully"<<endl;

        return;
    }

    while(ptr->next!=NULL){
        ptr= ptr->next ;
    }

    ptr->next = instPtr;
    cout<<"Node inserted Successfully"<<endl;


}

void push(nd **head_ref, int value){

    nd * instPtr = new nd;
    instPtr -> data = value;
    instPtr->next = (*head_ref);
    (*head_ref)=instPtr;
    cout<<"Node inserted Successfully"<<endl;


}

void insertAtPosition(nd **head_ref, int value,int position){

    if(position > 0){
        nd * ptr = *head_ref;
        nd * instPtr = new nd;
        instPtr->data= value;
        if(position==1){
               instPtr->next = (*head_ref);
               (*head_ref)=instPtr;         
        }
        else{
        
        
        int i =2;
        while(i<position){

            ptr= ptr->next;
            i++;

        }
        
        instPtr->next = ptr->next; 
        ptr->next= instPtr;
   
        }

    cout<<"Node inserted Successfully"<<endl;
     return;

    }
    else{
        cout<<"Unable to create a node"<<endl;
    }

}

void display(nd * ptr){

    if(ptr==NULL){
        cout<<"Nothing to display"<<endl;
        return;
    }
    cout<<"Linked list is as below "<<endl;
    while(ptr!=NULL){
        cout<<ptr->data<<endl;
        ptr=ptr->next;
    }

}


void insertNode(){
    int opt;
    int position;
    int value;

        cout<<"Enter your value you want to insert into linked list : ";
        cin >>value;

        cout<<"Following the insertion mode for linked list \n1. Insert at beginning\n2. Insert at end\n3. Insert at a position\nEnter your choice : ";
        cin>>opt;
        switch(opt){
            case 1 : push(&head,value);
            break;
            case 2 : append(&head,value);
            break;
            case 3 : cout<<"Enter position where you want to insert yout value : ";
            cin>>position ;
            insertAtPosition(&head,value,position);
            break;

            defaut: 
            cout<<"Kindly enter the given options"<<endl;

        }

    

}

void linkedList(){

    int choice;

    while(1){
        cout<<"Enter your operation from the given oerations\n1. Insert a Node \n2. Display Linked LIst\n3. Exit\nEnter your Choice from the above options : ";
        cin>>choice;

        switch(choice){
            case 1: insertNode();
            break;
            case 2: display(head);
            break;
            case 3: exit(0);
            default:
            cout<<"Invalid choice kindly enter the right choice";
        }

    }

    

}



int main(){
    

    linkedList();
    return 0;
}