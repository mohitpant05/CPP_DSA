// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};


void insert(struct node ** ptr, int value){
    
    struct node * last = *ptr;
    struct node * newPtr= new struct node;
    
    newPtr->data = value;
    
    newPtr->next=NULL;
    
    if((*ptr)==NULL){
        (*ptr)=newPtr;
        return;
    }
    
    while(last->next != NULL){
        last=last->next;
    }
    
    last->next=newPtr;
    
    // if(ptr==NULL){
    //     struct node * temp=new struct node;
    //     temp->data= value;
    //     temp->next=NULL;
    //     (*ptr)=temp;
    //     cout<<"Node inserted Successfully "<<endl;
    // }
    // else{
    //     struct node * temp=new struct node;
    //     temp=*ptr;
        
    //     while(temp!=NULL){
    //         temp=temp->next;
    //     }
    //     temp->data= value;
    //     temp->next=(*ptr)->next;
    //     (*ptr)->next=temp;
    //     (*ptr)=temp;
        cout<<"Node inserted Successfully "<<endl;
       
        
    // }
    
}


// void display(struct node * head){
    
//     struct node * temp = head;
    
//     while(temp!=NULL){
//         cout<<temp->data<<endl;
//         temp=temp->next;
//     }
// }
void display(struct node *head){
    
    // struct node * temp = head;
    
    while(head!=NULL){
        cout<<head->data<<endl;
        head=head->next;
    }
}



int main() {
    
   struct node * head=NULL;
    
    insert(&head,46);
     cout<<"Data at head is "<<head->data<<endl;
     insert(&head,36);
     cout<<"Data at head is "<<head->data<<endl;
     insert(&head,26);
     cout<<"Data at head is "<<head->data<<endl;
     
    //  display(head);
     display(head);
     insert(&head,29);
display(head);

     
    
cout<<head->data;
    return 0;
}