#include<iostream>

using namespace std;

typedef struct node{
    int data;
    struct node * next;
}nd;

// Append will add a node at the end 

void append(struct node ** head_ref, int value){

    nd * last = *head_ref;
    nd * temp = new nd;
    temp->data = value;
    temp->next= NULL;

    if((*head_ref)==NULL){
        (*head_ref) = temp;
        cout<<"Node inserted successfully"<<endl;
        return;
    }

    while(last->next!=NULL){
        last=last->next;
    }

    last->next= temp;
        cout<<"Node inserted successfully"<<endl;





}

// Push will add a node at the beginning 
void push(struct node **head_ref, int value){

    nd * newNode = new nd;
    newNode->data= value;

    newNode->next=*head_ref;
    *head_ref=newNode;
        cout<<"Node inserted successfully"<<endl;
    


}

// insertAtPosition will add a node at a particular position 

void insertAtPosition(struct node **head_ref,int value, int position){
    if(position >0){

        nd * temp = new nd;
        temp->data = value;
        nd * ptr = *head_ref;
        

        int i = 1;
        while(i<position){
            ptr = ptr->next;
            i++;
        }

        temp->next = ptr->next;
        ptr->next=temp;

        cout<<"Node inserted successfully"<<endl;

    }

    else if (position == 0 ){
        // nd * ptr = *head_ref;
        // push(&ptr,value);

        cout<<"Kindly use push operation to insert at beginninng";
    }

    else{
        cout<<"Unable to enter node at your position "<<endl;
    }
}


void display(nd * ptr){

    while(ptr!=NULL){
        cout<<ptr->data<<endl;
        ptr=ptr->next;
    }

}

int main(){

    nd * head = NULL;
    push(&head,47);
    append(&head, 46);
    append(&head,78);
    insertAtPosition(&head, 22,1);
    push(&head,97);
    push(&head,98);
    push(&head,99);
    display(head);
    return 0;


}