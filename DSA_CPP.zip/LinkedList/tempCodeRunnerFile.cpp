// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

struct node{
    int data;
    struct node * next;
};


void insert(struct node * ptr, int value){
    
    if(ptr==NULL){
        ptr->data= value;
        ptr->next=NULL;
        cout<<"Node inserted Successfully "<<endl;
    }
    
}




int main() {
    
    struct node * head;
    
    if(head==NULL){
        cout<<head<<endl;
        cout<<"hello world";
    }
    

    return 0;
}